﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using AlmDashboard.Models;
using AlmDashboard.VSOHelpers;

namespace AlmDashboard.Controllers
{
    public class VsoController : ApiController
    {
        private readonly VsoHelper _helper = new VsoHelper("ssw", "damianbrady", "Perfect2009!");

        [HttpGet]
        [Route("api/Projects")]
        public IEnumerable<TfsProject> GetProjects()
        {
            return _helper.GetProjects();
        }

        [HttpGet]
        [Route("api/Builds")]
        public IEnumerable<TfsBuild> GetBuilds()
        {
            return _helper.GetBuilds();
        }
        
        [HttpGet]
        [Route("api/Changesets")]
        public IEnumerable<TfvcChangeset> GetChangesets()
        {
            return _helper.GetChangesets();
        }

        [HttpGet]
        [Route("api/GitRepos")]
        public IEnumerable<GitRepository> GetGitRepos()
        {
            return _helper.GetGitRepositories();
        } 
    }
}
